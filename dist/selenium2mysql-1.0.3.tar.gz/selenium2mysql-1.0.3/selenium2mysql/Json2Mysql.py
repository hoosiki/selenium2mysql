import json
class Json2Mysql(object):
    def __init__(self):
        pass
